# FACTA catalog seed — Replit import instructions

This package contains 1,307 public online-catalog records collected on 2026-07-16. Treat it as a searchable catalog seed, not as verified ingredient, nutrition, allergen, barcode, or health-score data.

## Files

- `facta_product_seed.csv`: easiest for a database import.
- `facta_product_seed.json`: versioned JSON envelope with all records.
- `facta_product_seed.ndjson`: one record per line for a streaming seed script.
- `facta_product_seed.xlsx`: human review, source summary, QC notes, and field dictionary.
- `facta_seed_schema.sql`: isolated PostgreSQL staging table and indexes.

## Give this prompt to Replit

> Import the attached FACTA catalog seed into PostgreSQL as a staging/source table. First run `facta_seed_schema.sql`, then load `facta_product_seed.csv` using `facta_seed_id` as the idempotent primary key. Convert empty strings to NULL for price, calories, barcode, ingredients, allergens, and nutrition fields. Upsert catalog facts, but never overwrite non-empty human-verified label data with empty seed values. Do not calculate or display a health score for any row whose `verification_status` is `catalog_unverified` or whose `label_data_status` is `missing_label_data`. In search results, show a “Catalog data · label verification needed” badge and a CTA asking the user to photograph the product front, barcode, ingredient list, and nutrition label. Preserve `source_url`, `retrieved_at`, and `source_storefront`. Add search indexes for product name, brand, retailer, and normalized category. Keep retailer listings separate until a verified GTIN or human-reviewed canonical product link connects them.

## Required safety rules

1. `source_product_id` is a retailer catalog ID, not a GTIN.
2. `barcode_gtin` is intentionally blank in this seed.
3. Do not infer ingredients, allergens, nutrition, or dietary suitability from the product name.
4. Do not generate FACTA scores until label data has passed the verification workflow.
5. Online listing and price do not prove that every physical store stocks the product.
6. Before automated refreshes or image caching, review retailer terms, robots rules, rate limits, permitted reuse, and attribution.

## Recommended data flow

1. Import into `facta_catalog_seed`.
2. Search using catalog fields only.
3. On an unknown/unverified result, collect four photos: front, barcode, ingredients, nutrition.
4. OCR into a pending-label table; do not update verified production facts directly.
5. Human or trusted-review approval creates/updates the canonical product.
6. Only the canonical verified product enters scoring, evidence, allergen, goal-fit, and alternative-product systems.

## QC expectations after import

- Total rows: `1307`
- Unique `facta_seed_id`: `1307`
- Missing product names: `0`
- Missing observed prices: `0`
- Verified GTINs: `0` by design
- Rows needing label photos: `1307`

Source counts:

- 7-ELEVEN: 546
- FamilyMart Taiwan: 347
- Costco Taiwan: 390
- Uni-Prosperity Online: 24
