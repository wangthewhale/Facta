-- FACTA catalog seed staging schema (PostgreSQL)
-- Run this before importing facta_product_seed.csv.

create table if not exists facta_catalog_seed (
  facta_seed_id text primary key,
  retailer text not null,
  source_storefront text,
  source_product_id text not null,
  product_name text not null,
  brand_raw text,
  category_raw text,
  category_normalized text,
  spec_raw text,
  price_twd numeric(12,2),
  price_text_raw text,
  unit_price_raw text,
  currency char(3) default 'TWD',
  calories_kcal numeric(12,2),
  description_raw text,
  availability_raw text,
  image_url text,
  source_url text not null,
  category_url text,
  catalog_scope text,
  barcode_gtin text,
  ingredients_raw text,
  allergen_raw text,
  nutrition_raw text,
  label_data_status text not null default 'missing_label_data',
  verification_status text not null default 'catalog_unverified',
  import_status text not null default 'ready_catalog_seed',
  needs_label_photo boolean not null default true,
  physical_store_availability text not null default 'unknown',
  catalog_completeness_score integer,
  retrieved_at date not null,
  source_terms_note text,
  imported_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint facta_catalog_seed_completeness_check
    check (catalog_completeness_score between 0 and 100),
  constraint facta_catalog_seed_verification_check
    check (verification_status in ('catalog_unverified', 'label_pending_review', 'verified')),
  constraint facta_catalog_seed_label_status_check
    check (label_data_status in ('missing_label_data', 'pending_review', 'verified'))
);

create unique index if not exists facta_catalog_seed_source_uidx
  on facta_catalog_seed (retailer, source_product_id, product_name);

create index if not exists facta_catalog_seed_product_name_idx
  on facta_catalog_seed using gin (to_tsvector('simple', coalesce(product_name, '')));

create index if not exists facta_catalog_seed_brand_idx
  on facta_catalog_seed (brand_raw);

create index if not exists facta_catalog_seed_category_idx
  on facta_catalog_seed (category_normalized);

create index if not exists facta_catalog_seed_retailer_idx
  on facta_catalog_seed (retailer);

create index if not exists facta_catalog_seed_verification_idx
  on facta_catalog_seed (verification_status, needs_label_photo);

-- Import policy:
-- 1. Load CSV into this staging table using facta_seed_id for idempotent upsert.
-- 2. Convert empty strings to NULL where appropriate.
-- 3. Never overwrite later verified label facts with seed blanks.
-- 4. Keep retailer records separate until a verified GTIN or reviewed canonical link exists.
